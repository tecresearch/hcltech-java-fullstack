package com.hcl.turorial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TutorialManagementApplicationTests {

	@Test
	void contextLoads() {
		System.out.println("Spring Boot Loaded successfully");
	}

}
